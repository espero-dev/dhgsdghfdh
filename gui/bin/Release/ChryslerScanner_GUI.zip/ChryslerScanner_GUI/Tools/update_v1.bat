@echo off

TITLE Chrysler CCD/SCI Scanner (v1) manual firmware update

"%__APPDIR__%chcp.com" 65001
cls

if exist logo.txt type logo.txt

echo.
echo Instructions:
echo 1. Disconnect from the scanner and close the GUI. Keep USB cable connected.
echo 2. Edit update_v1.bat file by replacing "COMX" with your actual COM-port, example: COM3 or COM15.
echo 3. Download latest flash file from https://raw.githubusercontent.com/laszlodaniel/ChryslerScanner/master/Arduino/ChryslerCCDSCIScanner/ChryslerCCDSCIScanner.ino.mega.hex
echo 4. Place flash file into this folder and execute update_v1.bat.
echo.
echo Press any key to begin update session or close this window to exit.

pause

for %%i in ("avrdude.exe" "avrdude.conf" "libusb0.dll" "ChryslerCCDSCIScanner.ino.mega.hex") do if not exist "%%i" echo Error: %%i is missing. & goto :PAUSE

avrdude.exe -C avrdude.conf -p m2560 -c wiring -P COMX -b 115200 -D -U flash:w:ChryslerCCDSCIScanner.ino.mega.hex:i

:PAUSE
pause