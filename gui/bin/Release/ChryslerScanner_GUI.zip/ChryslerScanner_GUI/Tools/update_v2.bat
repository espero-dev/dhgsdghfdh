@echo off

TITLE Chrysler Scanner (v2) manual firmware update

"%__APPDIR__%chcp.com" 65001
cls

if exist logo.txt type logo.txt

echo.
echo Instructions:
echo 1. Disconnect from the scanner and close the GUI. Keep USB cable connected.
echo 2. Edit update_v2.bat file by replacing "COMX" with your actual COM-port, example: COM3 or COM15.
echo 3. Download latest flash file from https://raw.githubusercontent.com/laszlodaniel/ChryslerScanner/master/PlatformIO/ChryslerScanner/src/ChryslerScanner.bin
echo 4. Place flash file into this folder and execute update_v2.bat.
echo.
echo Notes:
echo If update fails due to connection issues:
echo 1. Wait until esptool tries to connect to scanner
echo 2. Press both scanner buttons
echo 3. Release Reset button first
echo 4. Release Boot button last
echo 5. Flash update begins
echo.
echo Press any key to begin update session or close this window to exit.

pause

for %%i in ("esptool.exe" "bootloader.bin" "partition_custom_table.bin" "ota_data_initial.bin" "ChryslerScanner.bin") do if not exist "%%i" echo Error: %%i is missing. & goto :PAUSE

esptool.exe --chip esp32 --port COMX --baud 921600 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 40m --flash_size detect 0x1000 bootloader.bin 0x8000 partition_custom_table.bin 0xe000 ota_data_initial.bin 0x10000 ChryslerScanner.bin

:PAUSE
pause